package Controlador;

//import javax.swing.SwingUtilities;
import Vista.Interfaz;

public class Main {
    public static void main(String[] args) {
        //SwingUtilities.invokeLater(() -> {
        Interfaz interfaz = new Interfaz();
        interfaz.setVisible(true);
        //});
    }
}
