
package Modelo;

import java.io.Serializable;

public class Revista extends Material{
    
    public Revista(String id,String titulo, String autor, long ano, boolean esta) {
        super(id, titulo, autor, ano, esta);
    }
    
}
