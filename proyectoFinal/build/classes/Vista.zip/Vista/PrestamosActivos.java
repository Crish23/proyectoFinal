package Vista;

public class PrestamosActivos {
    
}
